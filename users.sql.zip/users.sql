-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Хост: sql204.blyz.ru
-- Время создания: Июл 31 2026 г., 16:40
-- Версия сервера: 11.4.12-MariaDB
-- Версия PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `bly_42412807_ruproject`
--

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(191) DEFAULT NULL,
  `username` varchar(64) NOT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `avatar` varchar(500) DEFAULT NULL,
  `role` enum('user','moderator','admin') DEFAULT 'user',
  `is_banned` tinyint(1) DEFAULT 0,
  `oauth_provider` varchar(64) DEFAULT NULL,
  `oauth_id` varchar(191) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `totp_secret` varchar(64) DEFAULT NULL,
  `totp_enabled` tinyint(1) DEFAULT 0,
  `oauth_access_token` varchar(255) DEFAULT NULL,
  `is_verified` tinyint(1) NOT NULL DEFAULT 0,
  `phone` varchar(20) DEFAULT NULL,
  `xp` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `total_active_days` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `cycle_number` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `login_streak_days` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `last_active_date` date DEFAULT NULL,
  `gravatar_email` varchar(191) DEFAULT NULL,
  `must_change_password` tinyint(1) NOT NULL DEFAULT 0,
  `password_reset_by_admin_at` datetime DEFAULT NULL,
  `username_changed_at` datetime DEFAULT NULL,
  `role_changed_at` datetime DEFAULT NULL,
  `longest_login_streak` int(11) NOT NULL DEFAULT 0,
  `profile_cover_url` varchar(500) DEFAULT NULL,
  `profile_status_text` varchar(120) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `email`, `username`, `password_hash`, `avatar`, `role`, `is_banned`, `oauth_provider`, `oauth_id`, `created_at`, `totp_secret`, `totp_enabled`, `oauth_access_token`, `is_verified`, `phone`, `xp`, `total_active_days`, `cycle_number`, `login_streak_days`, `last_active_date`, `gravatar_email`, `must_change_password`, `password_reset_by_admin_at`, `username_changed_at`, `role_changed_at`, `longest_login_streak`, `profile_cover_url`, `profile_status_text`) VALUES
(1, 'fillshowyt@gmail.com', 'admin', '$2y$10$duaujjLZTdDAplsO4ezWEeA8bN3FdMO8X6gTavAXARGbzZnHETti2', NULL, 'admin', 0, NULL, NULL, '2026-07-07 17:39:49', '6W5YKGF7VJKNHXHHBTIPK2BGE32RO72C', 1, NULL, 1, '+79226888234', 442, 13, 1, 13, '2026-07-30', 'fillshowyt@gmail.com', 0, NULL, NULL, NULL, 13, NULL, NULL),
(2, 'twixoffshelby@yandex.com', 'Twixoff', '$2y$10$h9x05E8vANVYqLcO6RYx6e5Or6mWgSvGbdOKCuprB3TsRLePFuglS', NULL, 'admin', 0, NULL, NULL, '2026-07-07 18:09:06', '4RNHFLTUJ7WDU3USQDQLSGW6B6YC2IUK', 1, NULL, 1, '+79134545567', 490, 14, 1, 14, '2026-07-31', 'twix_off@vk.com', 0, NULL, '2026-07-26 03:09:58', NULL, 14, NULL, NULL),
(3, 'ginkdev@mail.ru', 'OinkTech', '$2y$10$c/NYKenFkNBVt0DfIl6Rru8GUo97q/NU3h8U4qvO3ZwU5LsMr1p/S', NULL, 'admin', 1, NULL, NULL, '2026-07-07 18:26:03', NULL, 0, NULL, 1, NULL, 0, 0, 1, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL),
(4, 'fi.ll.sh.o.w.yt@gmail.com', 'FLEXDEV', '$2y$10$cupGyCJaijoO4Kseizfep.5sBYwXND.VDZ0o7MukBVeY5vs/6ZM8y', NULL, 'admin', 1, NULL, NULL, '2026-07-07 20:40:30', NULL, 0, NULL, 1, NULL, 0, 0, 1, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL),
(5, 'akkakaraseva@yandex.ru', 'akkakaraseva@yandex.ru', '$2y$10$y32jZdAXh8EwtBhGjvfIiewe7F2eWDXcXAf9WVVNizAVEUsEtLluK', NULL, 'user', 0, NULL, NULL, '2026-07-07 22:47:23', NULL, 0, NULL, 0, NULL, 0, 0, 1, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL),
(6, NULL, 'yandex_6a4f589d69cb6', NULL, NULL, 'user', 0, 'yandex', '6a4f589d69cb6', '2026-07-09 01:15:25', NULL, 0, NULL, 0, NULL, 0, 0, 1, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL),
(7, NULL, 'yandex_6a4f5901019e8', NULL, NULL, 'user', 0, 'yandex', '6a4f5901019e8', '2026-07-09 01:17:05', NULL, 0, NULL, 0, NULL, 0, 0, 1, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL),
(8, NULL, 'yandex_6a4f6042ced6d', NULL, NULL, 'user', 0, 'yandex', '6a4f6042ced6d', '2026-07-09 01:48:03', 'HM7VZ6DO32SJUM6MHSPB425XSKO37J5J', 0, NULL, 0, NULL, 0, 0, 1, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL),
(10, 'ginkdevru@mail.ru', 'Adminchik', '$2y$10$uRUm6IIZpt1/7q01BHCV4.6XURyXjHPE7tLGoPC10omWyM0uWqi3a', NULL, 'admin', 0, NULL, NULL, '2026-07-09 03:06:04', 'YSGP6XSJSJAUJH3BLC6ERLUHTQ5PG5TM', 1, NULL, 1, NULL, 0, 0, 1, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL),
(11, 'id09071987@gmail.com', '7 999 209 43 67', '$2y$10$UT2BZi40hAfCFLaIPWk..eJICqV.cuSMWq97Yq0isgxImQjLIJnZq', NULL, 'user', 0, NULL, NULL, '2026-07-09 12:56:50', NULL, 0, NULL, 0, NULL, 0, 0, 1, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL),
(12, 'isvwdzp143@1secmail.ru', 'LiveStreamNews', '$2y$10$ZQlf6tkGptbFhEqO0lwtWOVIs7TKKx943V1rpRZlC3Mg6b9UT/9/q', NULL, 'admin', 0, NULL, NULL, '2026-07-14 14:54:57', 'BK33K6LMB5FDUVW2UGCG4DHJ6LSFYXGK', 1, NULL, 1, '+79124522032', 46, 2, 1, 2, '2026-07-22', NULL, 0, NULL, NULL, NULL, 0, NULL, NULL),
(13, 'dima.ataman708@gmail.com', 'Dimon2222', '$2y$10$79vRNY4d9cIBgjnwWppcTO8x1E8Fh0czMidXN7LRc/0hNwVur2kaC', NULL, 'user', 1, NULL, NULL, '2026-07-15 20:51:47', 'RCK2UQZK4TDQCCDD2SLXQA36KGW4BKLE', 0, NULL, 0, '+79132544012', 0, 0, 1, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL),
(14, 'abobus@gmail.com', 'DarkYT', '$2y$10$I8UtewZV3y.M1eUckZzgReicMwFds34vtuLOZNbUCorZYA9o38WCi', NULL, 'moderator', 0, NULL, NULL, '2026-07-20 02:54:16', NULL, 0, NULL, 1, '+79156697632', 0, 0, 1, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL),
(15, 'ginkdev12@mail.ru', 'OinkTechLtd', '$2y$10$fWt7tdPhRrvOFVOcTYZsNOho.n5ydufD5OU0dEd8CK1fcJpAdFPm.', NULL, 'admin', 0, NULL, NULL, '2026-07-21 01:36:43', 'NTQXDKLNNFBVZ7F5YRPAV2TSCMUE2HDX', 1, NULL, 1, '+79128715289', 68, 3, 1, 1, '2026-07-27', NULL, 0, NULL, NULL, NULL, 1, NULL, NULL),
(16, 'tuktamyshevmr2013six@gmail.com', 'Marko', '$2y$10$ss7LBixG6NzIl44kmZDEXO8pzyEvElwAJorqkQk9mQUbqgKVRRlQy', NULL, 'user', 0, NULL, NULL, '2026-07-22 14:58:40', NULL, 0, NULL, 1, NULL, 0, 0, 1, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL),
(17, 'matveyvladimer1234@gmail.com', 'AlexbusDeleted', '$2y$10$iZDHxk2lBPm0iynM0ozskODvgUVr06.pOZ7tlg3DYWXxipxHj5Y6K', NULL, 'user', 1, NULL, NULL, '2026-07-22 14:58:40', NULL, 0, NULL, 0, NULL, 0, 0, 1, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL),
(18, 'ff@djkd.eu', 'storoz', '$2y$10$xGHstHmM2XiXckuJA1JYpeizEXF0VtnbYPMGvyoxVc1PDZ9uBndBC', NULL, 'user', 0, NULL, NULL, '2026-07-22 14:58:40', NULL, 0, NULL, 0, NULL, 0, 0, 1, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL),
(19, 'darkusatenko@gmail.com', 'AdskayBaza', '$2y$10$/p8EujByITNirkSaysKV9.VQP8Lk1dy.2/l9s11P2iq/fkzN9hQse', NULL, 'user', 0, NULL, NULL, '2026-07-22 16:15:06', NULL, 0, NULL, 0, NULL, 0, 0, 1, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL),
(20, 'fillshow.yt@gmail.com', 'frash', '$2y$10$HuBg7Y5B5CyX9BhsYLa6Lec89bWExeg9HdkxPfJExZ/pwcNfpS6Aa', NULL, 'user', 0, NULL, NULL, '2026-07-22 16:15:07', NULL, 0, NULL, 0, NULL, 0, 0, 1, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL),
(21, 'alexbusinessman8@gmail.com', 'Vladimir_Dollars', '$2y$10$7wr3ztsNlhqutM7WHjb4OOeTAlkuOdgjo5yHTdIDzKKn0gqHyLy8.', NULL, 'user', 0, NULL, NULL, '2026-07-22 16:15:07', NULL, 0, NULL, 0, NULL, 0, 0, 1, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL),
(22, 'fillshowy.t@gmail.com', 'VovaPalka', '$2y$10$4u7LeHo.LJfDaTFp3ujVXOld5a3gMPZGOB58sUUqzz2XeoEzG4ZUu', NULL, 'user', 0, NULL, NULL, '2026-07-22 16:15:07', NULL, 0, NULL, 0, NULL, 0, 0, 1, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL),
(23, 'twix_off@vk.com', 'Palka', '$2y$10$exzkD.T/vOc7yUc6C1mQHOBigNOgJKC5qWsvhGHB8JjigN2DMXrWy', NULL, 'user', 0, NULL, NULL, '2026-07-22 16:15:07', NULL, 0, NULL, 0, NULL, 0, 0, 1, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL),
(24, 'matveyvladimer123@gmail.com', 'Alexbus', '$2y$10$8rQ9lBP1qSRSAeg1ayDfoOSqo3rZ8Inz3uaBTuuaewlcihd/sR2WG', NULL, 'user', 0, NULL, NULL, '2026-07-25 01:28:45', 'XWF2SCE6TJV6BRILFSJJ6GXL43NFZ746', 1, NULL, 1, '+79901835690', 22, 1, 1, 1, '2026-07-25', NULL, 0, NULL, NULL, NULL, 0, NULL, NULL);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone` (`phone`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
