-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Хост: sql204.blyz.ru
-- Время создания: Июл 31 2026 г., 16:42
-- Версия сервера: 11.4.12-MariaDB
-- Версия PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `bly_42412807_ruproject`
--

-- --------------------------------------------------------

--
-- Структура таблицы `channels`
--

CREATE TABLE `channels` (
  `id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('tv','radio') NOT NULL DEFAULT 'tv',
  `logo_url` varchar(500) DEFAULT NULL,
  `default_source_id` int(11) DEFAULT NULL,
  `status` enum('pending','approved','rejected','hidden') DEFAULT 'pending',
  `reject_reason` varchar(500) DEFAULT NULL,
  `seo_title` varchar(200) DEFAULT NULL,
  `seo_description` varchar(400) DEFAULT NULL,
  `seo_keywords` varchar(400) DEFAULT NULL,
  `views` bigint(20) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `rtmp_server` varchar(255) DEFAULT NULL,
  `stream_key_enc` varchar(500) DEFAULT NULL,
  `stream_key_iv` varchar(64) DEFAULT NULL,
  `rtmp_playback_url` varchar(500) DEFAULT NULL,
  `is_broadcast_paused` tinyint(1) NOT NULL DEFAULT 0,
  `is_public` tinyint(1) NOT NULL DEFAULT 1,
  `last_stream_live` tinyint(1) DEFAULT NULL,
  `last_stream_checked_at` datetime DEFAULT NULL,
  `hidden_reason` varchar(500) DEFAULT NULL,
  `hidden_by` int(11) DEFAULT NULL,
  `hidden_at` datetime DEFAULT NULL,
  `gravatar_email` varchar(191) DEFAULT NULL,
  `cover_url` varchar(500) DEFAULT NULL,
  `locked_by_admin` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `channels`
--

INSERT INTO `channels` (`id`, `owner_id`, `slug`, `title`, `description`, `type`, `logo_url`, `default_source_id`, `status`, `reject_reason`, `seo_title`, `seo_description`, `seo_keywords`, `views`, `created_at`, `rtmp_server`, `stream_key_enc`, `stream_key_iv`, `rtmp_playback_url`, `is_broadcast_paused`, `is_public`, `last_stream_live`, `last_stream_checked_at`, `hidden_reason`, `hidden_by`, `hidden_at`, `gravatar_email`, `cover_url`, `locked_by_admin`) VALUES
(1, 1, 'телеканал-солнце-afe930', 'Телеканал ТНТ', '', 'tv', NULL, 3, 'approved', NULL, 'Телеканал ТНТ', 'Телеканал ТНТ', 'Тв онлайн смотреть бесплатно без смс', 213, '2026-07-07 17:42:26', NULL, NULL, NULL, NULL, 0, 1, 1, '2026-07-15 03:06:54', NULL, NULL, NULL, NULL, NULL, 0),
(2, 1, 'телеканал-солнце-7de048', 'Телеканал Солнце', '', 'tv', NULL, 4, 'approved', NULL, 'Телеканал Солнце', 'Солнце', 'Тв онлайн смотреть бесплатно без смс', 193, '2026-07-07 17:52:13', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(3, 2, 'россия-1-87cb08', 'Россия 1', '', 'tv', NULL, 5, 'rejected', 'Нарушение правил платформы', 'Россия 1', 'Россия 1', 'Тв онлайн смотреть бесплатно без смс', 30, '2026-07-07 18:12:25', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(4, 1, 'первый-канал-b24110', 'Первый Канал', '', 'tv', NULL, 6, 'approved', NULL, 'Смотреть Первый Канал', 'Смотреть первый канал', 'Тв онлайн смотреть бесплатно без смс', 121, '2026-07-07 18:16:40', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(5, 1, 'адская-база-68e593', 'Адская База', 'Стример', 'tv', NULL, 7, 'approved', NULL, 'Смотреть Адская База', 'Смотреть', 'Тв онлайн смотреть бесплатно без смс', 53, '2026-07-07 18:50:14', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(6, 1, 'оборонный-кавказец-af74c5', 'Оборонный Кавказец', '', 'tv', 'https://avatars.mds.yandex.net/i?id=7f401bdb87bcaa595ad1ff02a0cfeb93_l-12422990-images-thumbs&n=13', 8, 'approved', NULL, 'Смотреть Оборонный Кавказец', 'Смотрим ТВ', 'Тв онлайн смотреть бесплатно без смс', 821, '2026-07-07 18:52:23', NULL, NULL, NULL, NULL, 0, 1, 0, '2026-07-15 03:09:48', NULL, NULL, NULL, NULL, NULL, 0),
(7, 1, 'телеканал-дождь-5335a8', 'Телеканал Дождь', '', 'tv', NULL, 8, 'approved', NULL, 'Смотреть Телеканал Дождь', '', 'Тв онлайн смотреть бесплатно без смс', 84, '2026-07-07 19:15:55', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(8, 1, 'быдло-ты-ебанная-12441b', 'быдло ты ебанная', '', 'tv', NULL, NULL, 'rejected', 'Оск проекта', 'быдло ты ебанная', '', NULL, 0, '2026-07-07 19:16:47', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(9, 1, 'стс-a8c5fa', 'СТС', 'СТС РФ', 'tv', NULL, 15, 'approved', NULL, 'Смотреть СТС', 'СТС РФ', 'Тв онлайн смотреть бесплатно без смс', 267, '2026-07-07 19:38:01', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(10, 1, 'пятый-канал-5-канал-46b2bd', 'ПЯТЫЙ КАНАЛ (5 КАНАЛ)', '', 'tv', NULL, 17, 'approved', NULL, 'Смотреть ПЯТЫЙ КАНАЛ (5 КАНАЛ)', '5 КАНАЛ РОССИЯ', 'Тв онлайн смотреть бесплатно без смс', 82, '2026-07-07 20:14:35', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(11, 4, 'ptashka-835a46', 'PTASHKA', 'VK VIDEO LIVE', 'tv', NULL, 18, 'approved', NULL, 'PTASHKA', 'STREAMERS', 'VK VIDEO LIVE', 74, '2026-07-07 20:41:47', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(12, 1, 'слушаем-релакс-bd4711', 'Слушаем релакс', '', 'radio', NULL, 19, 'rejected', 'Нарушение правил платформы', 'Слушаем релакс', '', '', 61, '2026-07-07 20:49:29', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(13, 5, 'дом-тимоша-9ad3cf', 'Дом тимоша', 'Дом Тимоша создан от моей Фили И каркуши+', 'tv', NULL, NULL, 'rejected', 'Нарушение правил платформы', 'Дом тимоша', 'Дом Тимоша создан от моей Фили И каркуши+', NULL, 1, '2026-07-07 22:50:18', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(14, 5, 'тимофей-1a9547', 'Тимофей', 'Тимофей в стиле телеканала время', 'tv', NULL, 2, 'rejected', 'Дубликат', 'Тимофей', 'Тимофей в стиле телеканала время', NULL, 0, '2026-07-07 22:55:11', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(15, 1, 'время-b01958', 'Время', 'ВРЕМЯ ДЛЯ РФ', 'tv', NULL, 20, 'approved', NULL, 'Смотреть Время', '', 'Тв онлайн смотреть бесплатно без смс', 39, '2026-07-08 07:30:57', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(16, 1, 'бридж-32d2b3', 'БРИДЖ', '', 'tv', NULL, 21, 'approved', NULL, 'Смотреть БРИДЖ', '', 'Тв онлайн смотреть бесплатно без смс', 41, '2026-07-08 07:33:52', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(17, 1, 'телеканал-солнце-с-впн-1e9d00', 'Телеканал Солнце (С ВПН) (МИР)', '', 'tv', NULL, 22, 'approved', NULL, 'Смотреть Телеканал Солнце (С ВПН)', 'Мировой', 'Тв онлайн смотреть бесплатно без смс', 46, '2026-07-08 07:35:14', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(18, 5, 'теле-тимоша-3ad6a6', 'Теле Тимоша', 'Телеканал для детей', 'tv', NULL, 2, 'rejected', 'Нарушение правил платформы', 'Теле Тимоша', 'Телеканал для детей', NULL, 1, '2026-07-08 08:16:14', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(19, 1, 'танки-онлайн-81f07c', 'ТАНКИ ОНЛАЙН', '', 'tv', NULL, 24, 'approved', NULL, 'ТАНКИ ОНЛАЙН', '', 'Тв онлайн смотреть бесплатно без смс', 43, '2026-07-08 09:13:30', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(20, 1, 'карусель-d46ff0', 'Карусель', '', 'tv', NULL, 36, 'approved', NULL, 'Карусель', '', 'Тв онлайн смотреть бесплатно без смс', 31, '2026-07-08 09:16:44', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(21, 1, 'дом-кино-d39e2e', 'ЛДПР', '', 'tv', NULL, 25, 'approved', NULL, 'Смотреть Трансляцию ЛДПР', '', 'Тв онлайн смотреть бесплатно без смс', 50, '2026-07-08 09:16:52', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(22, 1, 'fon-music-8e1b31', 'FON MUSIC', '', 'radio', NULL, 26, 'rejected', 'Нарушение правил платформы', 'FON MUSIC', '', 'Тв онлайн смотреть бесплатно без смс', 8, '2026-07-08 09:23:17', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(23, 1, 'дом-кино-d74f61', 'Дом кино', '', 'tv', NULL, 27, 'approved', 'Нарушение правил платформы', 'Дом кино', '', 'Тв онлайн смотреть бесплатно без смс', 46, '2026-07-08 09:28:26', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(24, 1, 'дом-кино-премиум-17a0e7', 'Дом Кино Премиум', '', 'tv', NULL, 28, 'approved', 'Нарушение правил платформы', 'Дом Кино Премиум', '', 'Тв онлайн смотреть бесплатно без смс', 55, '2026-07-08 09:32:13', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(25, 1, 'нтв-россия-d36e30', 'НТВ (Россия)', '', 'tv', NULL, 30, 'approved', NULL, 'НТВ (Россия)', '', 'Тв онлайн смотреть бесплатно без смс', 36, '2026-07-08 09:41:45', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(26, 1, 'нтв-мир-703e35', 'НТВ (МИР)', '', 'tv', NULL, 31, 'approved', NULL, 'НТВ (МИР)', '', 'Тв онлайн смотреть бесплатно без смс', 31, '2026-07-08 09:46:25', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(27, 1, 'нтв-сериал-ef7435', 'НТВ СЕРИАЛ', '', 'tv', NULL, 33, 'approved', NULL, 'НТВ СЕРИАЛ', '', 'Тв онлайн смотреть бесплатно без смс', 36, '2026-07-08 09:48:33', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(28, 1, 'нтв-сериал-c6efcb', 'НТВ СЕРИАЛ (Смотрим)', '', 'tv', NULL, 34, 'approved', NULL, 'Смотрим НТВ СЕРИАЛ', '', 'Тв онлайн смотреть бесплатно без смс', 79, '2026-07-08 10:09:03', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(29, 1, 'vk-video-live-8ac5fe', 'VK VIDEO LIVE', '', 'tv', NULL, 37, 'approved', NULL, 'VK VIDEO LIVE', '', 'Тв онлайн смотреть бесплатно без смс', 37, '2026-07-08 10:18:54', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(30, 1, 'cкрипачка-f7a995', 'Cкрипачка', '', 'tv', NULL, 38, 'approved', NULL, 'Cкрипачка', '', 'Тв онлайн смотреть бесплатно без смс', 33, '2026-07-08 10:20:42', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(31, 1, 'мир-танков-1f5e7e', 'МИР ТАНКОВ', '', 'tv', NULL, 39, 'approved', NULL, 'МИР ТАНКОВ', '', 'Тв онлайн смотреть бесплатно без смс', 33, '2026-07-08 10:24:29', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(32, 2, 'russia-tv-5ed773', 'Russia TV', '', 'tv', NULL, NULL, 'rejected', 'дубликат', 'Russia TV', '', NULL, 0, '2026-07-08 11:09:14', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(33, 1, 'нетфликс-87c730', 'Нетфликс', '', 'tv', NULL, 40, 'approved', NULL, 'Смотрим Нетфликс', '', 'Тв онлайн смотреть бесплатно без смс', 110, '2026-07-08 12:55:56', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(34, 3, 'россия-страна-будущего-53729a', 'Россия – Страна Будущего', '', 'tv', NULL, NULL, 'rejected', 'мало информации', 'Россия – Страна Будущего', '', NULL, 0, '2026-07-08 15:08:21', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(35, 3, 'fon-music-dc97e9', 'FON Music', '', 'tv', NULL, NULL, 'rejected', 'дубликат', 'FON Music', '', 'Тв онлайн смотреть бесплатно без смс', 0, '2026-07-08 15:29:04', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(36, 1, 'россия-1-359d0b', 'Россия 1', '', 'tv', NULL, 46, 'approved', NULL, 'Россия 1', '', 'Тв онлайн смотреть бесплатно без смс', 52, '2026-07-08 16:20:21', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(37, 1, 'россия-1-4f6a62', 'Россия 1', '', 'tv', NULL, 48, 'approved', NULL, 'Смотреть Россия 1', '', 'Тв онлайн смотреть бесплатно без смс', 25, '2026-07-08 16:25:10', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(38, 1, 'мистер-бин-7bcd62', 'Мистер Бин', '', 'tv', NULL, 49, 'approved', NULL, 'Мистер Бин', '', 'Тв онлайн смотреть бесплатно без смс', 18, '2026-07-09 21:25:53', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(39, 1, '4к-bfddfb', '4К', '', 'tv', NULL, 50, 'approved', NULL, '4К', '', 'Тв онлайн смотреть бесплатно без смс', 14, '2026-07-09 21:27:18', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(40, 1, 'россия-1-европа-d98e3f', 'Россия 1 Европа', '', 'tv', NULL, 51, 'approved', NULL, 'Россия 1 Европа', '', 'Тв онлайн смотреть бесплатно без смс', 20, '2026-07-09 21:59:45', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(41, 1, 'sss-0af12a', 'Твое ТВ Юмор', '', 'tv', NULL, 52, 'approved', NULL, 'Смотреть Твое ТВ Юмор', '', 'Тв онлайн смотреть бесплатно без смс', 14, '2026-07-09 22:47:43', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(42, 1, 'твое-тв-1e1271', 'Твое ТВ', '', 'tv', NULL, 53, 'approved', NULL, 'Твое ТВ', '', 'Тв онлайн смотреть бесплатно без смс', 19, '2026-07-10 00:32:08', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(43, 1, 'фронтовые-новости-f72338', 'ФРОНТОВЫЕ НОВОСТИ', '', 'tv', NULL, 54, 'approved', NULL, 'ФРОНТОВЫЕ НОВОСТИ', '', 'Тв онлайн смотреть бесплатно без смс', 15, '2026-07-10 00:35:46', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(44, 1, 'первый-республиканский-2a2d4c', 'Первый Республиканский', '', 'tv', NULL, 56, 'approved', NULL, 'Первый Республиканский', '', 'Тв онлайн смотреть бесплатно без смс', 14, '2026-07-10 00:37:24', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(45, 1, 'за-e849c9', 'За!', '', 'tv', NULL, 57, 'approved', NULL, 'За!', '', 'Тв онлайн смотреть бесплатно без смс', 9, '2026-07-10 08:12:05', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(46, 1, 'эхо-тв-9e4bd9', 'Эхо ТВ', '', 'tv', NULL, 58, 'approved', NULL, 'Эхо ТВ', '', 'Тв онлайн смотреть бесплатно без смс', 10, '2026-07-10 08:15:55', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(47, 1, 'рутуб-381b41', 'РУТУБ', '', 'tv', NULL, 59, 'approved', NULL, 'РУТУБ', '', 'Тв онлайн смотреть бесплатно без смс', 9, '2026-07-10 08:20:09', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(48, 2, 'инфоканал-b7304d', 'Смотрим Российское ТВ (Инфо Канал)', 'Провайдер Ростелеком  источники предназначены мы не забираем права на показ', 'tv', NULL, 67, 'approved', NULL, 'Российское ТВ по неделям', '', 'Тв онлайн смотреть бесплатно без смс', 19, '2026-07-10 09:07:16', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(49, 2, 'матч-тв-c3b0f4', 'МАТЧ ТВ', '', 'tv', NULL, 66, 'approved', NULL, 'МАТЧ ТВ', '', 'Тв онлайн смотреть бесплатно без смс', 15, '2026-07-11 01:45:31', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(50, 2, 'все-в-одном-wink-d9a3a9', 'Все в одном Wink', '', 'tv', NULL, 67, 'approved', NULL, 'Все в одном Wink', '', 'Тв онлайн смотреть бесплатно без смс', 23, '2026-07-11 09:11:25', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(51, 2, 'россия-1-1c764f', 'Россия 1', '', 'tv', NULL, 5, 'hidden', NULL, 'Россия 1', '', 'Тв онлайн смотреть бесплатно без смс', 12, '2026-07-11 10:59:04', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, 'Авторские права', 2, '2026-07-25 02:21:13', NULL, NULL, 0),
(52, 2, 'тнт4-2e9d0b', 'ТНТ4', '', 'tv', NULL, 71, 'approved', NULL, 'ТНТ4', '', 'Тв онлайн смотреть бесплатно без смс', 128, '2026-07-11 14:44:30', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(53, 2, 'чика-6c0878', 'Чика', 'Чика телеканал как Артур Пирожков.', 'tv', NULL, NULL, 'rejected', 'Неправильное название проекта', 'Чика', '', '', 0, '2026-07-11 16:23:06', NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(54, 1, 'rtvi-4351fc', 'RTVI', '', 'tv', NULL, 72, 'approved', NULL, 'RTVI', '', 'Тв онлайн смотреть бесплатно без смс', 32, '2026-07-11 21:54:34', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(55, 1, 'суббота-058da0', 'Суббота!', 'Суббота!', 'tv', NULL, NULL, 'rejected', 'Дубликат', 'Суббота!', '', 'Тв онлайн смотреть бесплатно без смс', 0, '2026-07-12 16:05:47', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(56, 1, 'суббота-ff459e', 'Суббота!', '', 'tv', NULL, 73, 'rejected', 'Нарушение правил платформы', 'Суббота!', '', 'Тв онлайн смотреть бесплатно без смс', 2, '2026-07-12 17:23:30', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(57, 2, 'мировые-новости-097d3c', 'Мировые новости', '', 'tv', NULL, NULL, 'rejected', 'не одобряем', 'Мировые новости', '', 'Тв онлайн смотреть бесплатно без смс', 0, '2026-07-12 17:35:56', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(58, 1, 'отр-46c060', 'ОТР', '', 'tv', NULL, 74, 'approved', NULL, 'ОТР', '', 'Тв онлайн смотреть бесплатно без смс', 13, '2026-07-12 19:06:04', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(59, 1, 'смотрим-алмазный-край-0f4dd7', 'Смотрим Алмазный Край', 'Смотрим Алмазный Край', 'tv', NULL, 75, 'approved', NULL, 'Смотрим Алмазный Край', '', 'Тв онлайн смотреть бесплатно без смс', 26, '2026-07-12 23:00:27', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(60, 1, 'ростелеком-тв-0fdbae', 'Ростелеком ТВ', '', 'tv', NULL, NULL, 'rejected', 'ДУБЛИКАТ', 'Ростелеком ТВ', '', 'Тв онлайн смотреть бесплатно без смс', 0, '2026-07-13 19:17:24', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(61, 1, 'ростелеком-тв-b9c910', 'Ростелеком ТВ', '', 'tv', NULL, 1231, 'rejected', 'Нарушение правил платформы', 'Ростелеком ТВ', '', 'Тв онлайн смотреть бесплатно без смс', 1, '2026-07-14 15:53:24', NULL, NULL, NULL, NULL, 0, 1, 1, '2026-07-15 01:54:06', NULL, NULL, NULL, NULL, NULL, 0),
(62, 1, 'братишкин-тв-a026f3', 'Братишкин ТВ', '', 'tv', NULL, 1232, 'approved', NULL, 'Братишкин ТВ', '', 'Тв онлайн смотреть бесплатно без смс', 70, '2026-07-14 16:25:06', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(63, 1, 'tv-ec90ec', 'ВК ВИДЕО', '', 'tv', NULL, NULL, 'rejected', 'Это канал на видеохостинге', 'ВК ВИДЕО', '', 'Тв онлайн смотреть бесплатно без смс ВК ВИДЕО', 0, '2026-07-17 16:07:54', NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(64, 2, 'youtube-2381de', 'YouTube', '', 'tv', NULL, NULL, 'rejected', 'Это канал на видеохостинге', 'YouTube', '', NULL, 0, '2026-07-17 16:40:22', NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(65, 1, 'россия-будущего-0e4c61', 'РОССИЯ БУДУЩЕГО', '', 'tv', NULL, NULL, 'rejected', 'Канал для видеохостинга', 'РОССИЯ БУДУЩЕГО', '', NULL, 0, '2026-07-17 17:45:49', NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(66, 1, 'самп-5fdb5b', 'САМП', '', 'tv', NULL, NULL, 'rejected', 'Канал для видеохостинга', 'САМП', '', NULL, 0, '2026-07-17 21:11:15', NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(67, 2, 'русское-на-век-b54c22', 'Русское – на ВЕК', '', 'tv', NULL, NULL, 'rejected', 'Канал для видеохостинга', 'Русское – на ВЕК', '', NULL, 0, '2026-07-18 00:48:20', NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(68, 2, 'инфлюренс-468dff', 'Инфлюренс', '', 'tv', NULL, NULL, 'rejected', 'Канал на видеохостинге', 'Инфлюренс', '', NULL, 0, '2026-07-18 01:05:27', NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(69, 2, 'инфлюренс-e94a79', 'Поставка на СВО', '', 'tv', NULL, NULL, 'rejected', 'Авторские Права', 'Инфлюренс', '', '', 0, '2026-07-18 01:05:30', NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(70, 1, 'россия-1---видео-ea73c4', 'Видосики', '', 'tv', NULL, NULL, 'rejected', 'дубликат', 'Россия 1 - Видео', '', '', 0, '2026-07-18 16:40:06', NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, 'twix_off@vk.com', NULL, 0),
(71, 2, 'шизонутые-тикток-18544f', 'Шизонутые Тикток', '', 'tv', NULL, NULL, 'rejected', 'отказано', 'Шизонутые Тикток', '', NULL, 0, '2026-07-19 01:00:18', NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(72, 2, 'российский-национальный-3b0a7a', 'Российский национальный', '', 'tv', NULL, NULL, 'rejected', 'Канал для видеохостинга', 'Российский национальный', '', 'Тв онлайн смотреть бесплатно без смс', 0, '2026-07-20 02:00:12', NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(73, 12, 'рен-тв-295d7e', 'РЕН ТВ', '', 'tv', NULL, 1233, 'approved', NULL, 'РЕН ТВ', '', 'russia smotret tv', 8, '2026-07-21 03:54:30', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(74, 12, 'мир-тв-577feb', 'МИР ТВ', '', 'tv', NULL, 1234, 'approved', NULL, 'МИР ТВ', '', 'russia smotret tv', 11, '2026-07-21 04:12:44', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(75, 12, 'тнт-тв-900764', 'ТНТ ТВ', '', 'tv', NULL, 1235, 'approved', NULL, 'ТНТ ТВ', '', 'russia smotret tv', 10, '2026-07-21 04:14:48', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(76, 12, 'тнт-7-b047c2', 'ТНТ +7', '', 'tv', NULL, 1236, 'rejected', 'Нарушение правил платформы', 'ТНТ +7', '', 'russia smotret tv', 3, '2026-07-21 04:40:46', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(77, 12, 'муз-тв-754eba', 'МУЗ ТВ', '', 'tv', NULL, 1237, 'approved', NULL, 'МУЗ ТВ', '', 'russia smotret tv', 9, '2026-07-21 04:45:30', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(78, 1, 'смотрим-западные-тв-90746f', 'Смотрим Западные ТВ', '', 'tv', NULL, 72, 'approved', NULL, 'Смотрим Западные ТВ', '', 'Тв онлайн смотреть бесплатно без смс', 15, '2026-07-21 04:48:33', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0);
INSERT INTO `channels` (`id`, `owner_id`, `slug`, `title`, `description`, `type`, `logo_url`, `default_source_id`, `status`, `reject_reason`, `seo_title`, `seo_description`, `seo_keywords`, `views`, `created_at`, `rtmp_server`, `stream_key_enc`, `stream_key_iv`, `rtmp_playback_url`, `is_broadcast_paused`, `is_public`, `last_stream_live`, `last_stream_checked_at`, `hidden_reason`, `hidden_by`, `hidden_at`, `gravatar_email`, `cover_url`, `locked_by_admin`) VALUES
(79, 2, 'отр-белгород-8e1005', 'ОТР Белгород', '', 'tv', NULL, NULL, 'rejected', 'не работает', 'ОТР Белгород', '', 'Тв онлайн смотреть бесплатно без смс', 0, '2026-07-21 05:02:06', NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(80, 12, 'крым-24-e50e35', 'КРЫМ 24', '', 'tv', NULL, 1238, 'rejected', 'Нарушение правил платформы', 'КРЫМ 24', '', NULL, 3, '2026-07-21 19:37:30', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(81, 12, 'москва-24-67e569', 'Москва 24', '', 'tv', NULL, 1239, 'approved', NULL, 'Москва 24', '', NULL, 1, '2026-07-21 19:39:02', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(82, 12, 'дорама-7cb59a', 'Дорама', '', 'tv', NULL, 1240, 'approved', NULL, 'Дорама', '', NULL, 3, '2026-07-21 19:44:01', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(83, 12, 'start-air-52a3de', 'START AIR', '', 'tv', NULL, 1241, 'approved', NULL, 'START AIR', '', NULL, 6, '2026-07-21 19:48:41', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(84, 12, 'start-world-08313b', 'START WORLD', '', 'tv', NULL, 1241, 'approved', NULL, 'START WORLD', '', '', 18, '2026-07-21 19:54:30', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(85, 12, 'start-world-2-a4405e', 'START WORLD 2', '', 'tv', NULL, 1242, 'approved', NULL, 'START WORLD 2', '', '', 11, '2026-07-21 19:57:35', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(86, 12, '360-канал-9687aa', '360 КАНАЛ', '', 'tv', NULL, 1243, 'approved', NULL, '360 КАНАЛ', '', NULL, 0, '2026-07-21 19:59:10', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(87, 12, 'okko-sport-31bd6a', 'Okko Sport', '', 'tv', NULL, 1244, 'approved', NULL, 'Okko Sport', '', NULL, 2, '2026-07-21 20:08:30', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(88, 1, 'большой-вопрос-79ac05', 'Большой Вопрос', '', 'tv', NULL, 1245, 'approved', NULL, 'Большой Вопрос', '', 'Тв онлайн смотреть бесплатно без смс', 0, '2026-07-21 20:18:22', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(89, 12, 'смешные-тв-453366', 'Смешные ТВ', '', 'tv', NULL, 1246, 'approved', NULL, 'Смешные ТВ', '', NULL, 0, '2026-07-21 20:21:35', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(90, 12, 'сваты-3f2477', 'СВАТЫ', '', 'tv', NULL, 1247, 'approved', NULL, 'СВАТЫ', '', 'russia smotret tv', 3, '2026-07-21 20:22:08', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(91, 12, 'смотрим-фильмы-сериалы-5af74c', 'Смотрим Фильмы Сериалы', '', 'tv', NULL, 1248, 'approved', NULL, 'Смотрим Фильмы Сериалы', '', NULL, 8, '2026-07-21 20:44:12', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(92, 12, 'смотримру-88a5ec', 'Смотрим.ру Smotrim', '', 'tv', NULL, 1253, 'approved', NULL, 'Смотрим.ру', '', '', 6, '2026-07-21 21:21:08', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(93, 12, 'нацисты-убивали-русских-39a98d', 'НАЦИСТЫ УБИВАЛИ РУССКИХ', '', 'tv', NULL, NULL, 'rejected', 'Авторские права', 'НАЦИСТЫ УБИВАЛИ РУССКИХ', '', NULL, 0, '2026-07-21 21:28:21', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(94, 12, 'nickedelon-tv-762807', 'nickedelon tv', '', 'tv', NULL, 1254, 'approved', NULL, 'nickedelon tv', '', NULL, 9, '2026-07-21 23:47:28', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(95, 12, 'мультики-тв-cdd14b', 'Мультики ТВ', '', 'tv', NULL, 1255, 'approved', NULL, 'Мультики ТВ', '', NULL, 9, '2026-07-21 23:48:37', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(96, 12, 'bridge-tv-e90609', 'BRIDGE TV', '', 'tv', NULL, 1262, 'approved', NULL, 'BRIDGE TV', '', '', 5, '2026-07-21 23:52:25', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(97, 12, 'киномикс-dca5ea', 'КИНОМИКС', '', 'tv', NULL, 1257, 'approved', NULL, 'КИНОМИКС', '', NULL, 1, '2026-07-21 23:55:50', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(98, 12, 'маша-и-медведь-682373', 'Маша и Медведь', '', 'tv', NULL, 1258, 'approved', NULL, 'Маша и Медведь', '', NULL, 1, '2026-07-22 00:09:07', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(99, 12, 'телеканал-о-965a74', 'Телеканал О!', '', 'tv', NULL, 1259, 'approved', NULL, 'Телеканал О!', '', NULL, 16, '2026-07-22 00:10:23', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(100, 12, '2x2-orig-7a64ba', '2x2 (orig)', '', 'tv', NULL, 1260, 'approved', NULL, '2x2 (orig)', '', NULL, 1, '2026-07-22 00:15:58', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(101, 12, 'дождь-признан-ино-агентом-в-рф-49e2c4', 'Дождь* Признан Нежелательной и Ино-Агентом в РФ', '', 'tv', NULL, 1261, 'approved', NULL, 'Дождь* Признан Нежелательной в РФ', '', '', 8, '2026-07-22 00:32:22', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(102, 1, 'smotrim-russian-video-7e3158', 'Smotrim (Russian Video)', '', 'tv', NULL, NULL, 'rejected', 'авторские права', 'Smotrim (Russian Video)', '', NULL, 0, '2026-07-22 02:04:01', NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(103, 1, 'смотрим-тнт-очень-древняя-русь-3f1445', 'Смотрим ТНТ', '', 'tv', NULL, NULL, 'rejected', 'Авторские права', 'Смотрим ТНТ', '', '', 0, '2026-07-22 03:34:12', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(104, 1, 'вк-видео-11db87', 'СИКС СЕВЕН ГАЗАН', '', 'tv', NULL, 1264, 'approved', NULL, 'Вк Видео', '', '', 5, '2026-07-22 21:54:09', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(105, 2, 'смотрим-5c3716', 'Смотрим', '', 'tv', NULL, 65, 'approved', NULL, 'Смотрим', '', '', 7, '2026-07-23 06:06:40', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(106, 2, 'шалтай-балтай-09878b', 'Шалтай балтай', '', 'tv', NULL, NULL, 'rejected', 'СПАМ', 'Шалтай балтай', '', NULL, 0, '2026-07-24 00:30:45', NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(107, 1, 'дума-тв-284605', 'Дума ТВ', '', 'tv', NULL, 1267, 'approved', NULL, 'Дума ТВ', '', '', 3, '2026-07-24 04:06:11', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(108, 1, 'кинеко-fda0e3', 'КИНЕКО', '', 'tv', NULL, 1268, 'approved', NULL, 'КИНЕКО', '', '', 0, '2026-07-24 04:30:14', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(109, 1, 'смотрим-мультики-2х2-096275', 'Смотрим Мультики 2х2', '', 'tv', NULL, 1269, 'approved', NULL, 'Смотрим Мультики 2х2', '', NULL, 0, '2026-07-24 04:34:15', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(110, 1, 'смотрим-фильмы-премиум-96997f', 'Смотрим Фильмы Премиум', '', 'tv', NULL, 1270, 'approved', NULL, 'Смотрим Фильмы Премиум', '', NULL, 1, '2026-07-24 04:35:24', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(111, 1, 'fon-music-679f0a', 'FON MUSIC', '', 'tv', NULL, 1271, 'approved', NULL, 'FON MUSIC', '', NULL, 1, '2026-07-24 04:39:42', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(112, 1, 'ю-0e31b7', 'Ю', '', 'tv', NULL, 1272, 'approved', NULL, 'Ю', '', NULL, 0, '2026-07-24 04:42:05', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(113, 1, 'tv3-0a1a21', 'TV3', 'ТВ3', 'tv', NULL, 1273, 'approved', NULL, 'TV3', '', '', 0, '2026-07-24 05:04:59', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(114, 1, 'нтв-сериал-481a7f', 'НТВ СЕРИАЛ', '', 'tv', NULL, 1274, 'approved', NULL, 'НТВ СЕРИАЛ', '', NULL, 7, '2026-07-24 05:06:17', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(115, 24, 'gaming-with-vladimir-4aa7e2', 'Gaming with Vladimir', 'Играю рп игры и рпг игры  только CRMP', 'tv', NULL, 2, 'approved', NULL, 'Gaming with Vladimir', 'Играю рп игры и рпг игры  только CRMP', '', 5, '2026-07-25 01:37:00', NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(116, 2, 'смотрим-kz-1a2ac3', 'Смотрим kz', '', 'tv', NULL, NULL, 'rejected', 'СПАМ', 'Смотрим kz', '', NULL, 0, '2026-07-26 03:19:30', NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(117, 2, 'манифисетта-8114fc', 'Манифисетта на русском', '', 'tv', NULL, NULL, 'rejected', 'СПАМ', 'Манифисетта', '', '', 0, '2026-07-26 06:10:20', NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(118, 1, 'юмор-фм-db589e', 'юмор фм', '', 'tv', NULL, 1275, 'approved', NULL, 'юмор фм', '', NULL, 5, '2026-07-27 23:00:47', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(119, 1, 'детское-радио-75254e', 'детское радио', '', 'tv', NULL, 1276, 'approved', NULL, 'детское радио', '', NULL, 1, '2026-07-27 23:09:32', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(120, 1, '11-украина-9a2b50', '1+1 Украина', '', 'tv', NULL, 1277, 'approved', NULL, '1+1 Украина', '', NULL, 1, '2026-07-28 00:29:53', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(121, 2, 'беларусь-70923a', 'Беларусь', '', 'tv', NULL, NULL, 'pending', NULL, 'Беларусь', '', NULL, 0, '2026-07-28 03:26:08', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(122, 1, 'мужское-и-женское-первый-канал-3041ae', 'Мужское и Женское (Первый Канал)', '', 'tv', NULL, 1278, 'approved', NULL, 'Мужское и Женское (Первый Канал)', '', '', 6, '2026-07-29 00:21:07', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(123, 1, 'webinar-school-vibecoding-3f21ed', 'webinar school vibecoding', '', 'tv', NULL, 1281, 'approved', NULL, 'webinar school vibecoding', '', '', 54, '2026-07-29 05:45:43', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(124, 1, 'смотрим-фильмы-c37e8a', 'Смешное Кино 18+', '', 'tv', NULL, 1282, 'approved', NULL, 'Смотрим Фильмы', '', '', 4, '2026-07-29 07:14:10', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(125, 1, 'kino-tv-2bb5a5', 'kino tv', '', 'tv', NULL, 1283, 'approved', NULL, 'kino tv', '', NULL, 2, '2026-07-30 02:15:33', NULL, NULL, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `channels`
--
ALTER TABLE `channels`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `owner_id` (`owner_id`),
  ADD KEY `default_source_id` (`default_source_id`);
ALTER TABLE `channels` ADD FULLTEXT KEY `ft_search` (`title`,`description`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `channels`
--
ALTER TABLE `channels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `channels`
--
ALTER TABLE `channels`
  ADD CONSTRAINT `channels_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `channels_ibfk_2` FOREIGN KEY (`default_source_id`) REFERENCES `sources` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
