-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Хост: sql102.infinityfree.com
-- Время создания: Июл 31 2026 г., 17:19
-- Версия сервера: 11.4.12-MariaDB
-- Версия PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `if0_42247856_flexdev`
--

-- --------------------------------------------------------

--
-- Структура таблицы `channels`
--

CREATE TABLE `channels` (
  `id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('tv','radio') NOT NULL DEFAULT 'tv',
  `logo_url` varchar(500) DEFAULT NULL,
  `default_source_id` int(11) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `reject_reason` varchar(500) DEFAULT NULL,
  `seo_title` varchar(200) DEFAULT NULL,
  `seo_description` varchar(400) DEFAULT NULL,
  `seo_keywords` varchar(400) DEFAULT NULL,
  `views` bigint(20) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `rtmp_server` varchar(255) DEFAULT NULL,
  `stream_key_enc` varchar(500) DEFAULT NULL,
  `stream_key_iv` varchar(64) DEFAULT NULL,
  `rtmp_playback_url` varchar(500) DEFAULT NULL,
  `is_broadcast_paused` tinyint(1) NOT NULL DEFAULT 0,
  `is_public` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `channels`
--

INSERT INTO `channels` (`id`, `owner_id`, `slug`, `title`, `description`, `type`, `logo_url`, `default_source_id`, `status`, `reject_reason`, `seo_title`, `seo_description`, `seo_keywords`, `views`, `created_at`, `rtmp_server`, `stream_key_enc`, `stream_key_iv`, `rtmp_playback_url`, `is_broadcast_paused`, `is_public`) VALUES
(1, 1, 'алмазный-гром-18ad61', 'Алмазный Гром', '', 'tv', 'https://smotret.tv/images/netflix-filmy-serialy.webp', 1, 'approved', NULL, 'Алмазный Гром', '', 'TV RUSSIA TV', 24, '2026-07-08 12:35:25', NULL, NULL, NULL, NULL, 0, 1);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `channels`
--
ALTER TABLE `channels`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `owner_id` (`owner_id`),
  ADD KEY `default_source_id` (`default_source_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `channels`
--
ALTER TABLE `channels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `channels`
--
ALTER TABLE `channels`
  ADD CONSTRAINT `channels_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `channels_ibfk_2` FOREIGN KEY (`default_source_id`) REFERENCES `sources` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
